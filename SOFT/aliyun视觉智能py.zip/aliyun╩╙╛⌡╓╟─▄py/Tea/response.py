class TeaResponse:
    # status
    status_code = None
    # reason
    status_message = None
    headers = None
    response = None
    body = None
